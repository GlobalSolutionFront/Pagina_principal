document.addEventListener("DOMContentLoaded", function() {
    const questions = document.querySelectorAll('.faq-question');

    questions.forEach(button => {
        button.addEventListener('click', () => {
            const answer = button.nextElementSibling;
            const isVisible = answer.style.display === 'block';

            // Fecha todas as respostas
            document.querySelectorAll('.faq-answer').forEach(p => p.style.display = 'none');

            // Alterna a resposta clicada
            if (!isVisible) {
                answer.style.display = 'block';
            }
        });
    });
});

