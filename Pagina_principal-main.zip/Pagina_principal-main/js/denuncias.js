document.getElementById('formDenuncia').addEventListener('submit', function (event) {
    event.preventDefault();

    const tipo = document.getElementById('tipo').value;
    const descricao = document.getElementById('descricao').value;
    const local = document.getElementById('local').value;

    alert(`Denúncia enviada com sucesso!\n\nTipo: ${tipo}\nLocal: ${local}\nDescrição: ${descricao}`);

    this.reset(); // limpa o formulário
});
