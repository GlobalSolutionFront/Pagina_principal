document.getElementById('loginForm').addEventListener('submit', function (event) {
    event.preventDefault();

    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;

    if (email && senha) {
        alert(`Bem-vindo(a), ${email}!`);
         window.location.href = "Pagina_principal-main/chatbot.html"
    } else {
        alert("Preencha todos os campos.");
    }

    this.reset();
});


